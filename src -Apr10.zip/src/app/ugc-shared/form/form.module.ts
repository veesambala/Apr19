import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormMaterialInputComponent } from './material-input/material-input.component';
import { FormMaterialCheckboxComponent } from './material-checkbox/material-checkbox.component'

@NgModule({
  declarations: [
    FormMaterialInputComponent,
    FormMaterialCheckboxComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    FormMaterialInputComponent,
    FormMaterialCheckboxComponent
    
  ]
})
export class FormModule {}
