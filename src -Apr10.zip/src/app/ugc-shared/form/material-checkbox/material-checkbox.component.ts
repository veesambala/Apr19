import { Component, ChangeDetectionStrategy, ChangeDetectorRef, Input, Output, EventEmitter } from '@angular/core';
import { MediaFile } from '../../services/media-upload/file/file.service';

@Component({
  selector: 'form-material-checkbox',
  templateUrl: './material-checkbox.component.html',
  styleUrls: ['./material-checkbox.component.scss', './material-checkbox.component.theme.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FormMaterialCheckboxComponent {
  @Output()
  public onValueChangedEvent: EventEmitter<boolean> = new EventEmitter();

  
  @Input()
  public set required(required: boolean) {
    this._required = required;
  }
  @Input()
  public set disabled(disabled:boolean) {
    this._disabled=disabled;
  }
  public get disabled(): boolean {
    return this._disabled;
  }
  @Input()
  public set startingState(startingValue:boolean){
    this._startingState=startingValue;
  }
  public get startingState():boolean{
    return this._startingState;
  }
  @Input()
  public set label(label:string){
    this._label=label;
  }
  public get label():string{
    return this._label;
  }
  private _required: boolean;
  private _disabled:boolean;
  private _label:string;
  private _errored: boolean;
  private _id: string = '';
  private _startingState:boolean;

  constructor(
    private _changeDetector: ChangeDetectorRef
  ) { }
  public onChange($event): void {  
    this._startingState=!this._startingState;
    this.onValueChangedEvent.next(this._startingState);
  }

  private validateValue(): void {
    // if (this.required && !this._value) {
    //   this._errored = true;
    //   // this._error = this.requiredText.replace('__PLACE_HOLDER__', this.placeHolder);
    // }
    this._changeDetector.detectChanges();
  }
}

export interface ValueEvent {
  value: string;
  error: boolean;
}
