import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { BurstLogService } from '../../core/services/logging/log.service';

export const MAX_FILES_PER_UPLOAD: number = 5;
export const MAX_VIDEOS_PER_UPLOAD: number = 1;

@Injectable()
export class UploadTrackerService {
  public get onFilesChanged(): Observable<any> {
    console.log('_uploadFilesTracker: onFilesChanged', this._filesList);
    return this._onFilesChanged;
  }

  public get onFileAddError(): Observable<FileError> {
    return this._onFileAddError;
  }

  public get onFilesTitleChanged(): Observable<string> {
    return this._onFilesTitleChanged;
  }

  public get onUsersInfoChanged(): Observable<{}> {
    return this._usersInfoChanged;
  }

  public get filesList(): File[] {
    return this._filesList;
  }

  public get maxFiles(): boolean {
    return this._filesList.length >= MAX_FILES_PER_UPLOAD;
  }

  public get videoFilesCount(): number {
    let count: number = 0;

    this._filesList.forEach((file: File) => {
      if (isVideoFile(file)) {
        count++;
      }
    });

    return count;
  }

  public get imageFilesCount(): number {
    let count: number = 0;

    this._filesList.forEach((file: File) => {
      if (isImageFile(file)) {
        count++;
      }
    });

    return count;
  }

  public get filesTitle(): string {
    return this._filesTitle;
  }

  public set filesTitle(val: string) {
    this._log.debug(`UploadTrackerService: Setting files title to ${val}`);
    this._filesTitle = val;
    this._onFilesTitleChangedEvent.next(val);
  }

  public get usersInfo(): {} {
    return this._usersInfo;
  }

  private _onFilesChangedEvent: Subject<any> = new Subject();
  private _onFilesChanged: Observable<any> = this._onFilesChangedEvent.asObservable();
  private _onFileAddErrorEvent: Subject<FileError> = new Subject();
  private _onFileAddError: Observable<FileError> = this._onFileAddErrorEvent.asObservable();
  private _onFilesTitleChangedEvent: Subject<string> = new Subject();
  private _onFilesTitleChanged: Observable<string> = this._onFilesTitleChangedEvent.asObservable();
  private _usersInfoChangedEvent: Subject<{}> = new Subject();
  private _usersInfoChanged: Observable<{}> = this._usersInfoChangedEvent.asObservable();

  private _filesList: File[];
  private _filesTitle: string;
  private _usersInfo: {};

  constructor(
    private _log: BurstLogService
  ) {
    console.log('_uploadFilesTracker Initialization', this._filesList);
    this.clear();
  }

  public clear(): void {
    this._log.debug('UploadTrackerService: Clearing out files in files list');
    this._filesList = [];
    this._filesTitle = '';
    this._usersInfo = {};
  }

  public addFile(addFile: File): void {
    this._log.debug(`UploadTrackerService: Adding file to files list: ${addFile.name}`);

    if (!addFile) {
      this._log.error('UploadTrackerService: Rejecting empty file from user');
      this._onFileAddErrorEvent.next({
        error: 'EMPTY',
        file: addFile
      });

      return;
    }

    if (this.fileExists(addFile)) {
      this._log.info(`UploadTrackerService: Rejecting file from user as duplicate: ${addFile.name}`);
      this._onFileAddErrorEvent.next({
        error: 'DUPLICATE',
        file: addFile
      });

      return;
    }

    if (this.maxFiles) {
      this._log.info(`UploadTrackerService: Rejecting file from user, max files reached: ${addFile.name}`);
      this._onFileAddErrorEvent.next({
        error: 'MAXIMUM_REACHED',
        file: addFile
      });

      return;
    }

    if (this.videoFilesCount >= MAX_VIDEOS_PER_UPLOAD && isVideoFile(addFile)) {
      this._log.info(`UploadTrackerService: Rejecting file from user, max video files reached: ${addFile.name}`);
      this._onFileAddErrorEvent.next({
        error: 'MAXIMUM_VIDEOS_REACHED',
        file: addFile
      });

      return;
    }
    this._filesList.push(addFile);
    this._onFilesChangedEvent.next();
  }

  public removeFile(removeFile: File): void {
    this._log.debug(`UploadTrackerService: Removing file from files list: ${removeFile.name}`);
    let index: number = this._filesList.indexOf(removeFile);
    this._filesList.splice(index, 1);
    this._onFilesChangedEvent.next();
  }

  public getUsersInfoField(field: string): string {
    if (!(field in this._usersInfo)) {
      return '';
    }

    return this._usersInfo[field];
  }

  public setUsersInfoField(field: string, value: string): void {
    this._log.debug(`UploadTrackerService: Setting users info field ${field} to ${value}`);
    this._usersInfo[field] = value;
  }

  private fileExists(file: File): boolean {
    for (let index: number = 0; index < this._filesList.length; index++) {
      if (this._filesList[index].name === file.name) {
        return true;
      }
    }

    return false;
  }
}

export function isVideoFile(file: File): boolean {
  return file.type.indexOf('video') > -1;
}

export function isImageFile(file: File): boolean {
  return file.type.indexOf('image') > -1;
}

export interface FileError {
  error: FileAddErrors;
  file: File;
}

export type FileAddErrors = 'EMPTY' | 'DUPLICATE' | 'MAXIMUM_REACHED' | 'MAXIMUM_VIDEOS_REACHED';
