import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { MobileHeaderDisplayType } from '../../ugc-shared/theme/page-layout/mobile-header/mobile-header.component';
import { PromptType } from './shared/submission-prompt/submission-prompt.component';
import { Subscription } from 'rxjs/Subscription';
import {
  FileAddErrors, FileError, MAX_FILES_PER_UPLOAD, MAX_VIDEOS_PER_UPLOAD,
  UploadTrackerService
} from '../../ugc-shared/upload-tracker/upload-tracker.service';
import { Router } from '@angular/router';
import { UgcCustomizationService } from '../../ugc-shared/http/customization/customization.service';
import { ToasterService } from '../../ugc-shared/toaster/toaster.service';
import { StaticUtils } from '../../ugc-shared/static-utils';

@Component({
  selector: 'ugc-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class UgcLandingComponent implements OnInit, OnDestroy {
  public get mobileHeaderDisplayType(): MobileHeaderDisplayType {
    if (this._submissionPromptType === 'IMAGE') {
      return 'PROJECTED_XLARGE';
    }

    return 'PROJECTED_LARGE';
  }

  private _submissionPromptType: PromptType = 'TEXT_ONLY';
  private _errorTrackerSubscription: Subscription;
  private _fileError: FileAddErrors;

  constructor(
    private _router: Router,
    private _changeDetector: ChangeDetectorRef,
    private _uploadTracker: UploadTrackerService,
    private _customizationService: UgcCustomizationService,
    private _toasterService: ToasterService
  ) { }

  public ngOnInit() {
    this._uploadTracker.clear();
    this._errorTrackerSubscription = this._uploadTracker.onFileAddError.subscribe(
      (error: FileError) => {
        this._fileError = error.error;
        this.setFileUploadError(error);
        console.log(this._fileError);
      }
    );
  }

  public ngOnDestroy(): void {
    if (this._errorTrackerSubscription) {
      this._errorTrackerSubscription.unsubscribe();
      this._errorTrackerSubscription = null;
    }
  }

  /**
   * Method to inform that the upload button has been clicked
   * On click, will set the selected file in upload tracker and route to the ugc/upload screens
   */
  public uploadSelectedFile(file: File) {
    this._uploadTracker.addFile(file);
    this._changeDetector.detectChanges();
    console.log(this._uploadTracker.filesList);
    this._router.navigate(['/ugc/upload'], { queryParams: StaticUtils.queryParams });
  }

  /**
   * Method to inform that the not now button has been clicked
   * On click, will route to the provided url
   *
   * @param {string} url the external resource location to route the window to
   */
  public notNowClicked(url: string) {
    window.location.href = url;
  }

  /**
   * Method to inform when the prompt type has been changed
   * The prompt type corresponds to the submission prompt
   *
   * @param {PromptType} promptType
   */
  public promptTypeSet(promptType: PromptType): void {
    this._submissionPromptType = promptType;
    this._changeDetector.detectChanges();
  }

  private setFileUploadError(error: FileError): void {
    let errorType: FileAddErrors = error.error;
    let fileName: string = error.file ? error.file.name : '';

    this._toasterService.toasterStateText = 'SHOW';
    this._toasterService.toasterMessageText = this._customizationService.locales.current().emptyMediaError
      .replace('__NAME__', fileName);

    if (errorType === 'MAXIMUM_REACHED') {
      this._toasterService.toasterMessageText = this._customizationService.locales.current().maxMediaError
        .replace('__MAX__', MAX_FILES_PER_UPLOAD.toString());
    } else if (errorType === 'MAXIMUM_VIDEOS_REACHED') {
      this._toasterService.toasterMessageText = this._customizationService.locales.current().maxVideosError
        .replace('__MAX_VIDEOS__', MAX_VIDEOS_PER_UPLOAD.toString());
    } else if (errorType === 'DUPLICATE') {
      this._toasterService.toasterMessageText = this._customizationService.locales.current().duplicateMediaError
        .replace('__NAME__', fileName);
    }
  }
}
