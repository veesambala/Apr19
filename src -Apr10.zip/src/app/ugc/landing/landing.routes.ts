import { UgcLandingComponent } from './landing.component';

export const routes = [
  { path: '', component: UgcLandingComponent }
];
