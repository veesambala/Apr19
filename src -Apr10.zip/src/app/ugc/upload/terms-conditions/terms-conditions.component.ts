import { Component } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/http/customization/customization.service';
import { UgcErrorReportService } from '../../../ugc-shared/http/error-report/ugc-error-report.service';

@Component({
  selector: 'terms-conditions',
  templateUrl: './terms-conditions.component.html',
  styleUrls: ['./terms-conditions.component.scss', './terms-conditions.component.theme.scss']
})
export class TermsAndConditionComponent {
  public backText: string;
  public termsAndConditionAgreementText: string;
  public termsAndConditionText: string;
  public tcAgreePrompt: string;

  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService,
    private _ugcErrorReportService: UgcErrorReportService
  ) {
    this._buttonsService.primaryButtonState = 'NONE';
  }
}
