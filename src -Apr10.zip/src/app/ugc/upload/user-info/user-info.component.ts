import { Component, OnInit } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/http/customization/customization.service';

@Component({
  selector: 'user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.scss', './user-info.component.theme.scss']
})
export class UserInfoComponent implements OnInit {
  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService,
  ) {}
 public label:string;
  public ngOnInit() {
    this.setNextButtonState();
    this.label=this._customizationService.locales.current().termsAndConditionsAutoAcceptText;
  }

  private setNextButtonState() {
    this._buttonsService.primaryButtonText = this._customizationService.locales.current().nextText;
  }
  public valueChanged(value:boolean){
    console.log("value",value);
  }
}
