import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UgcDisplayModule } from './display/display.module';
import { UgcBrandingModule } from './branding/branding.module';
import { FormModule } from './form/form.module';
import { UgcHttpModule } from './http/http.module';
import { UgcThemeModule } from './theme/theme.module';
import { ToasterModule } from './toaster/toaster.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,

    FormModule,
    ToasterModule.forRoot(),

    UgcBrandingModule,
    UgcDisplayModule,
    UgcHttpModule,
    UgcThemeModule
  ],
  exports: [
    FormModule,
    ToasterModule,
    UgcBrandingModule,
    UgcDisplayModule,
    UgcHttpModule,
    UgcThemeModule
  ]
})
export class UgcSharedModule {
  public static forRoot(): ModuleWithProviders {
    return {
      ngModule: UgcSharedModule,
      providers: UgcHttpModule.providers()
    };
  }
}
