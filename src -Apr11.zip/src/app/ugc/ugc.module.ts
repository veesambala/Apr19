import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { UgcComponent } from './ugc.component';
import { routes } from './ugc.routes';

@NgModule({
    declarations: [
        UgcComponent,
    ],
    entryComponents: [],
    providers: [],
    imports: [RouterModule.forChild(routes)]
})
export class UgcModule {}
