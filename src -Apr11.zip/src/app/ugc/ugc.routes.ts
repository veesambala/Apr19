import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    children: [
        { path: '', redirectTo: 'landing', pathMatch: 'full' },
        { path: 'landing', loadChildren: './landing#UgcLandingModule' },
        { path: 'upload', loadChildren: './upload#UploadModule' }
    ]
  }
];
