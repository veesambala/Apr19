import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StepsProgressBarComponent } from './steps-progress-bar/steps-progress-bar.component';
import { ProgressStepComponent } from './steps-progress-bar/progress-step/progress-step.component';
import { StepsNavButtonsService } from './steps-nav-buttons/steps-nav-buttons.service';
import { StepsNavButtonsComponent } from './steps-nav-buttons/steps-nav-buttons.component';
import { UploadTrackerService } from './upload-tracker/upload-tracker.service';
import { UgcSharedModule } from '../../../ugc-shared/ugc-shared.module';

@NgModule({
  declarations: [
    StepsNavButtonsComponent,
    StepsProgressBarComponent,
    ProgressStepComponent
  ],
  imports: [
    CommonModule,
    UgcSharedModule
  ],
  exports: [
    StepsNavButtonsComponent,
    StepsProgressBarComponent
  ],
  providers: [
    StepsNavButtonsService,
    UploadTrackerService
  ]
})
export class UploadCoreModule { }
