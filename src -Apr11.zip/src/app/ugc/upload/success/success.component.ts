import { Component } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/http/customization/customization.service';
@Component({
  selector: 'upload-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.scss', './success.component.theme.scss']
})
export class SuccessComponent {
  public shareMedia: string;

  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService,
  ) {
    this._buttonsService.primaryButtonState = 'NONE';
  }
}
