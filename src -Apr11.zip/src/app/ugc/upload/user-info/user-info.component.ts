import { Component, OnInit } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/http/customization/customization.service';

@Component({
  selector: 'user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.scss', './user-info.component.theme.scss']
})
export class UserInfoComponent implements OnInit {
  public acceptenceText: string;
  public termsConditionsType: string;
  public validForm: boolean;
  public termsConditionsAccepted: boolean;
  public manualAcceptanceText:string;
  public stringManipulation:number;
  public anchoredAcceptanceText:string;
  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService,
  ) { }

  public ngOnInit() {
    this.acceptenceText = this._customizationService.locales.current().termsAndConditionsAutoAcceptText;
    this.termsConditionsType = this._customizationService.locales.current().termsConditionsType;
    this.stringManipulation=this.acceptenceText.indexOf("TERMS");
    this.manualAcceptanceText=this.acceptenceText.substring(0,this.stringManipulation);
    console.log(this.manualAcceptanceText);
    this.anchoredAcceptanceText=this.acceptenceText.substring(this.stringManipulation);
    console.log(this.anchoredAcceptanceText);
    this.setNextButtonState();
  }

  public valueChanged(value: boolean) {
    if (value) {
      this.termsConditionsAccepted = true;
    }
    if (this.validForm && this.termsConditionsAccepted) {
      this._buttonsService.primaryButtonState = 'ENABLED';
    }
  }
  public setButtonState(value: boolean) {
    if (value) {
      this.validForm = true;
    }
  }
  public enabledlink(value: boolean) {
    console.log("need to implement link further");

  }
  private setNextButtonState() {
    if(this._customizationService.locales.current().termsConditionsType!='page'){
      this._buttonsService.primaryButtonText=this._customizationService.locales.current().uploadText;
    }
    else{
    this._buttonsService.primaryButtonText = this._customizationService.locales.current().nextText;
    }
  }
}
