import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisplayLogoComponent } from './logo/logo.component';
import { DisplayLocalMediaFileComponent } from './local-media-file/local-media-file.component';

@NgModule({
  declarations: [
    DisplayLogoComponent,
    DisplayLocalMediaFileComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    DisplayLogoComponent,
    DisplayLocalMediaFileComponent
  ]
})
export class DisplayModule {}
