import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageProgressComponent } from './page-progress/page-progress.component';
import { UploadProgressComponent } from './upload-progress/upload-progress.component';
import { PreviewComponent } from './preview/preview.component';
import { DesktopBackgroundComponent } from './desktop-background/desktop-background.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { DefaultConfig } from '../factories/default-loader-config.factory';
import { DisplayModule } from './display/display.module';
import { UgcBrandingModule } from './ugc-branding/ugc-branding.module';
import { UgcThemeModule } from './ugc-theme/ugc-theme.module';

@NgModule({
  declarations: [
    DesktopBackgroundComponent,
    PageProgressComponent,
    PreviewComponent,
    UploadProgressComponent
  ],
  imports: [
    CommonModule,
    NgCircleProgressModule.forRoot(DefaultConfig),

    DisplayModule,
    UgcBrandingModule,
    UgcThemeModule
  ],
  exports: [
    DesktopBackgroundComponent,
    PageProgressComponent,
    PreviewComponent,
    UploadProgressComponent,

    DisplayModule,
    UgcBrandingModule,
    UgcThemeModule
  ]
})
export class SharedComponentsModule {}
