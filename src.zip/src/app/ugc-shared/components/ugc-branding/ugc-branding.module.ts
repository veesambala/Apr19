import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrandingLogosComponent } from './branding-logos/branding-logos.component';
import { DisplayModule } from '../display/display.module';

@NgModule({
  declarations: [
    BrandingLogosComponent
  ],
  imports: [
    CommonModule,
    DisplayModule
  ],
  exports: [
    BrandingLogosComponent
  ]
})
export class UgcBrandingModule {}
