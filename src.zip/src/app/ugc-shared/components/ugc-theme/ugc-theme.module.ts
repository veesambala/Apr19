import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UgcPageLayoutComponent } from './page-layout/page-layout.component';
import { DesktopRightPanelComponent } from './page-layout/desktop-right-panel/desktop-right-panel.component';
import { MobileHeaderComponent } from './page-layout/mobile-header/mobile-header.component';
import { UgcBackgroundComponent } from './background/background.component';
import { DisplayModule } from '../display/display.module';
import { UgcBrandingModule } from '../ugc-branding/ugc-branding.module';

@NgModule({
  declarations: [
    UgcPageLayoutComponent,
    DesktopRightPanelComponent,
    MobileHeaderComponent,
    UgcBackgroundComponent
  ],
  imports: [
    CommonModule,
    DisplayModule,
    UgcBrandingModule
  ],
  exports: [
    UgcPageLayoutComponent,
    UgcBackgroundComponent
  ]
})
export class UgcThemeModule {}
