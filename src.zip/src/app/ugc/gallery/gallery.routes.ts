import { GalleryComponent } from './gallery.component';
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

export const routes = [
  { path: '', component: GalleryComponent },
];