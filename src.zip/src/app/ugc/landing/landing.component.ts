import { ChangeDetectorRef, Component } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { MobileHeaderDisplayType } from '../../ugc-shared/components/ugc-theme/page-layout/mobile-header/mobile-header.component';
import { PromptType } from './shared/submission-prompt/submission-prompt.component';
import { QueryParams, StaticUtils } from '../../ugc-shared/services/static-utils';
import { Router } from '@angular/router';

@Component({
  selector: 'ugc-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class UgcLandingComponent {
  public get mobileHeaderDisplayType(): MobileHeaderDisplayType {
    if (this._submissionPromptType === 'IMAGE') {
      return 'PROJECTED_XLARGE';
    }

    return 'PROJECTED_LARGE';
  }

  private _submissionPromptType: PromptType = 'TEXT_ONLY';

  constructor(
    private _router: Router,
    private _changeDetector: ChangeDetectorRef
  ) { }

  /**
   * Method to inform that the upload button has been clicked
   * On click, will route to the ugc/upload screens
   */
  public uploadClicked() {
    this._router.navigate(['/ugc/upload'], { queryParams: StaticUtils.queryParams });
  }

  /**
   * Method to inform that the not now button has been clicked
   * On click, will route to the provided url
   *
   * @param {string} url the external resource location to route the window to
   */
  public notNowClicked(url: string) {
    window.location.href = url;
  }

  /**
   * Method to inform when the prompt type has been changed
   * The prompt type corresponds to the submission prompt
   *
   * @param {PromptType} promptType
   */
  public promptTypeSet(promptType: PromptType): void {
    this._submissionPromptType = promptType;
    this._changeDetector.detectChanges();
  }
}
