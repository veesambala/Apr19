import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SharedComponentsModule } from '../../ugc-shared/components/shared-components.module';
import { routes } from './landing.routes';
import { UgcLandingComponent } from './landing.component';
import { PoweredByComponent } from './shared/powered-by/powered-by.component';
import { UploadComponent } from './shared/upload/upload.component';
import { SubmissionPromptComponent } from './shared/submission-prompt/submission-prompt.component';

@NgModule({
  declarations: [
    UgcLandingComponent,
    PoweredByComponent,
    SubmissionPromptComponent,
    UploadComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SharedComponentsModule,
    RouterModule.forChild(routes)
  ],
  exports: []
})
export class UgcLandingModule {}
