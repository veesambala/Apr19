import { Component } from '@angular/core';
@Component({
  selector: 'ugc-splash',
  templateUrl: './splash.component.html',
  styleUrls: ['./splash.component.css']
})
export class SplashComponent {
}