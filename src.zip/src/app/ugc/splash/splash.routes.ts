import { SplashComponent } from './splash.component';
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

export const routes = [
  { path: '', component: SplashComponent },
];