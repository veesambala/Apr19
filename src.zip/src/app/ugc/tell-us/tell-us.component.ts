import { Component } from '@angular/core';
@Component({
  selector: 'ugc-tellus',
  templateUrl: './tell-us.component.html',
  styleUrls: ['./tell-us.component.css']
})
export class TellUsComponent {
}