import { Component, OnDestroy, OnInit } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/services/ugc-customization/ugc-customization.service';
import { UploadTrackerService } from '../core/upload-tracker.service';
import { Subscription } from 'rxjs/Subscription';
@Component({
  selector: 'add-media',
  templateUrl: './add-media.component.html',
  styleUrls: ['./add-media.component.scss', './add-media.component.theme.scss']
})
export class AddMediaComponent implements OnInit, OnDestroy {
  private _trackerSubscription: Subscription;

  constructor(
    private _uploadFilesTracker: UploadTrackerService,
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService
  ) {
    this._buttonsService.primaryButtonState = 'DISABLED';
    this._buttonsService.primaryButtonText = this._customizationService.locales.current().nextText;
  }

  public ngOnInit(): void {
    this._trackerSubscription = this._uploadFilesTracker.onFilesChanged.subscribe(
      () => {
        this.setMediaSelectionState();
      }
    );
    this.setMediaSelectionState();
  }

  public ngOnDestroy(): void {
    if (this._trackerSubscription) {
      this._trackerSubscription.unsubscribe();
      this._trackerSubscription = null;
    }
  }

  private setMediaSelectionState(): void {
    this._buttonsService.primaryButtonState = this._uploadFilesTracker.filesList.length > 0 ? 'ENABLED' : 'DISABLED';
  }
}
