import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedComponentsModule } from '../../../ugc-shared/components/shared-components.module';
import { AddMediaComponent } from './add-media.component';
import { AddMediaPromptComponent } from './add-media-prompt/add-media-prompt.component';
import { MediaAdderComponent } from './media-adder/media-adder.component';
import { MediaAdderButtonComponent } from './media-adder/media-adder-button/media-adder-button.component';

@NgModule({
  declarations: [
    AddMediaComponent,
    AddMediaPromptComponent,
    MediaAdderComponent,
    MediaAdderButtonComponent
  ],
  imports: [SharedComponentsModule, CommonModule],
  exports: []
})
export class AddMediaModule { }
