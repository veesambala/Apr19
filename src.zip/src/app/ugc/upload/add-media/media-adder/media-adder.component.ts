import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { UploadTrackerService } from '../../core/upload-tracker.service';
import {MediaUploadService} from '../../../../ugc-shared/services/media-upload/media-upload.service'

@Component({
  selector: 'media-adder',
  templateUrl: './media-adder.component.html',
  styleUrls: ['./media-adder.component.scss', './media-adder.component.theme.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class MediaAdderComponent {
  public get filesList(): File[] {
    return this._uploadFilesTracker.filesList;
  }

  constructor(
    private _uploadFilesTracker: UploadTrackerService,
    private _changeDetector: ChangeDetectorRef,
    private _mediaUploadService:MediaUploadService
  ) {}

  public fileSelected(file: File) {
    this._uploadFilesTracker.addFile(file);
    this._changeDetector.detectChanges();
  }

  public removeFile(file: File) {
    this._uploadFilesTracker.removeFile(file);
    this._changeDetector.detectChanges();
  }
}
