import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { BurstLogService } from '../../../core/services/logging/log.service';

export const MAX_FILES_PER_UPLOAD: number = 5;

@Injectable()
export class UploadTrackerService {
  public get onFilesChanged(): Observable<any> {
    return this._onFilesChangedEvent.asObservable();
  }

  public get onFileAddError(): Observable<FileError> {
    return this._onFileAddErrorEvent.asObservable();
  }

  public get filesList(): File[] {
    return this._filesList;
  }

  public get maxFiles(): boolean {
    return this._filesList.length >= MAX_FILES_PER_UPLOAD;
  }

  private _onFilesChangedEvent: Subject<any> = new Subject();
  private _onFileAddErrorEvent: Subject<FileError> = new Subject();
  private _filesList: File[];

  constructor(
    private _log: BurstLogService
  ) {
    this._filesList = [];
  }

  public clear(): void {
    this._log.debug('UploadTrackerService: Clearing out files in files list');
    this._filesList = [];
  }

  public addFile(addFile: File): void {
    this._log.debug('UploadTrackerService: Adding file to files list: ' + addFile.name);

    if (!addFile) {
      this._log.error('UploadTrackerService: Rejecting empty file from user');
      this._onFileAddErrorEvent.next({
        error: 'EMPTY',
        file: addFile
      });

      return;
    }

    if (this.fileExists(addFile)) {
      this._log.info('UploadTrackerService: Rejecting file from user as duplicate: ' + addFile.name);
      this._onFileAddErrorEvent.next({
        error: 'DUPLICATE',
        file: addFile
      });

      return;
    }

    if (this.maxFiles) {
      this._log.info('UploadTrackerService: Rejecting file from user, max files reached: ' + addFile.name);
      this._onFileAddErrorEvent.next({
        error: 'MAXIMUM_REACHED',
        file: addFile
      });

      return;
    }

    this._filesList.push(addFile);
    this._onFilesChangedEvent.next();
  }

  public removeFile(removeFile: File): void {
    this._log.debug('Removing file from files list: ' + removeFile.name);
    let index: number = this._filesList.indexOf(removeFile);
    this._filesList.splice(index, 1);
    this._onFilesChangedEvent.next();
  }

  private fileExists(file: File): boolean {
    for (let index: number = 0; index < this._filesList.length; index++) {
      if (this._filesList[index].name === file.name) {
        return true;
      }
    }

    return false;
  }
}

export interface FileError {
  error: FileAddErrors;
  file: File;
}

export type FileAddErrors = 'EMPTY' | 'DUPLICATE' | 'MAXIMUM_REACHED';
