import { Component } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/services/ugc-customization/ugc-customization.service';
import { UgcErrorReportService } from '../../../ugc-shared/services/ugc-error-report/ugc-error-report.service';
import { MediaUploadService } from '../../../ugc-shared/services/media-upload/media-upload.service';

@Component({
  selector: 'upload-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.scss', './progress.component.theme.scss']
})
export class ProgressComponent {
  public cancelText: string;
  public pageTitle: string;
  public filesList = [];

  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService,
    private _ugcErrorReportService: UgcErrorReportService,
    private _mediaUpload: MediaUploadService,
  ) {
    this.setText();
  }

  private setText() {
    this._buttonsService.primaryButtonState = 'NONE';
    this._buttonsService.primaryButtonText = this._customizationService.locales.current().nextText;

    if (this._mediaUpload.mediaUpload.mediaItems.length > 0) {
      this.filesList = this._mediaUpload.mediaUpload.mediaItems;
    }
    this.pageTitle = this._customizationService.c11nJson.locales.current().formPageTitle;
    this.cancelText = this._customizationService.c11nJson.locales.current().cancelText;
  }

}
