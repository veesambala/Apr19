import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedComponentsModule } from '../../../ugc-shared/components/shared-components.module';
import { ProgressComponent } from './progress.component';
import { ProgressInfoPromptComponent } from './progress-info-prompt/progress-info-prompt.component';

@NgModule({
  declarations: [
    ProgressComponent,
    ProgressInfoPromptComponent
  ],
  imports: [SharedComponentsModule, CommonModule],
  exports: []
})
export class ProgressModule { }
