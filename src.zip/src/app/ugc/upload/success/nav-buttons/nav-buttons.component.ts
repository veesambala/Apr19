import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UgcCustomizationService } from
  '../../../../ugc-shared/services/ugc-customization/ugc-customization.service';

@Component({
  selector: 'nav-buttons',
  templateUrl: './nav-buttons.component.html',
  styleUrls: ['./nav-buttons.component.scss', './nav-buttons.component.theme.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NavButtonsComponent {
  public addMore: string;
  public finished: string;
  public viewMedia: string;
  constructor(
    private _customizationService: UgcCustomizationService
  ) {
    this.setText();
  }

  public setText() {
    this.addMore = this._customizationService.locales.current().addMoreText;
    this.finished = this._customizationService.locales.current().finishedText;
    this.viewMedia = this._customizationService.locales.current().viewMediaText;
  }
}
