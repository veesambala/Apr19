import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedComponentsModule } from '../../../ugc-shared/components/shared-components.module';
import { SuccessComponent } from './success.component';
import { SuccessPromptComponent } from './success-prompt/success-prompt.component';
import { ShareMediaComponent } from './share-media/share-media.component';
import { NavButtonsComponent } from './nav-buttons/nav-buttons.component';

@NgModule({
  declarations: [
    SuccessComponent,
    SuccessPromptComponent,
    ShareMediaComponent,
    NavButtonsComponent
  ],
  imports: [SharedComponentsModule, CommonModule],
  exports: []
})
export class SuccessModule { }
