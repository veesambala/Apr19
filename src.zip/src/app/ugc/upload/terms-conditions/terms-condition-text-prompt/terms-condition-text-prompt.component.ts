import { Component, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';
import { UgcCustomizationService } from
  '../../../../ugc-shared/services/ugc-customization/ugc-customization.service';

@Component({
    selector: 'tc-text-prompt',
    templateUrl: './terms-condition-text-prompt.component.html',
    styleUrls: ['./terms-condition-text-prompt.component.scss', './terms-condition-text-prompt.component.theme.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class TermsConditionTextPromptComponent {
  public termsAndConditionText: string;
  public tcAgreePrompt: string;

  constructor(
    private _customizationService: UgcCustomizationService
  ) {
      this.setText();
  }

  public setText() {
    this.termsAndConditionText = this._customizationService.locales.current().termsAndConditionsPageTitle;
    this.tcAgreePrompt = this._customizationService.locales.current().termsAndConditionAgreePrompt;
  }
}
