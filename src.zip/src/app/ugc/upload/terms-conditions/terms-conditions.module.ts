import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedComponentsModule } from '../../../ugc-shared/components/shared-components.module';
import { TermsAndConditionComponent } from './terms-conditions.component';
import { TcAgreementTextPromptComponent } from './tc-agreement-prompt/tc-agreement-prompt.component';
import { TermsConditionTextPromptComponent } from './terms-condition-text-prompt/terms-condition-text-prompt.component';

@NgModule({
  declarations: [
    TermsAndConditionComponent,
    TcAgreementTextPromptComponent,
    TermsConditionTextPromptComponent
  ],
  imports: [SharedComponentsModule, CommonModule, FormsModule],
  exports: []
})
export class TermsAndConditionModule { }
