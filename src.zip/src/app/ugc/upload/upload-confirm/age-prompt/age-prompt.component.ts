import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UgcCustomizationService } from
  '../../../../ugc-shared/services/ugc-customization/ugc-customization.service';

@Component({
    selector: 'age-prompt',
    templateUrl: './age-prompt.component.html',
    styleUrls: ['./age-prompt.component.scss', './age-prompt.component.theme.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class AgePromptComponent {
  public ageConfirmationText: string;

  constructor(
    private _customizationService: UgcCustomizationService
  ) {
      this.setText();
  }

  public setText() {
    this.ageConfirmationText = this._customizationService.locales.current().ageConfirmationText;
  }
}
