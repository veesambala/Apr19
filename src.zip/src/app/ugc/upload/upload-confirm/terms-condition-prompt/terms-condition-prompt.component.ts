import { Component, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';
import { UgcCustomizationService } from
  '../../../../ugc-shared/services/ugc-customization/ugc-customization.service';

@Component({
    selector: 'terms-condition-prompt',
    templateUrl: './terms-condition-prompt.component.html',
    styleUrls: ['./terms-condition-prompt.component.scss', './terms-condition-prompt.component.theme.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class TermsAndConditionPromptComponent {
  @Output()
  public onTcLinkClicked: EventEmitter<UIEvent> = new EventEmitter();

  public tcAgreePrompt: string;
  public termsAndCondition: string;

  constructor(
    private _customizationService: UgcCustomizationService
  ) {
      this.setText();
  }

  public onTermsClicked() {
    this.onTcLinkClicked.emit();
  }

  public setText() {
    this.termsAndCondition = this._customizationService.locales.current().termsAndConditionsPageTitle;
    this.tcAgreePrompt = this._customizationService.locales.current().termsAndConditionAgreePrompt;
  }
}
