import { Component } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { Router } from '@angular/router';
import { StaticUtils } from '../../../ugc-shared/services/static-utils';

@Component({
  selector: 'upload-confirmation',
  templateUrl: './upload-confirmation.component.html',
  styleUrls: ['./upload-confirmation.component.scss', './upload-confirmation.component.theme.scss']
})
export class UploadConfirmComponent {
  public termsAndCondition: string;
  public tcAgreePrompt: string;
  public ageConfirmationText: string;
  public ageConfirmation = false;
  public tcConfirmation = false;

  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _router: Router
  ) {
    this._buttonsService.primaryButtonState = 'ENABLED';
    this._buttonsService.primaryButtonText = 'UPLOAD';
  }

  public navigateTcPage() {
    this._router.navigate(['/ugc/upload/terms-conditions'], { queryParams: StaticUtils.queryParams });
  }
}
