import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedComponentsModule } from '../../../ugc-shared/components/shared-components.module';
import { UploadConfirmComponent } from './upload-confirmation.component';
import { TermsAndConditionPromptComponent } from './terms-condition-prompt/terms-condition-prompt.component';
import { AgePromptComponent } from './age-prompt/age-prompt.component';

@NgModule({
  declarations: [
    UploadConfirmComponent,
    TermsAndConditionPromptComponent,
    AgePromptComponent
  ],
  imports: [SharedComponentsModule, CommonModule, FormsModule],
  exports: []
})
export class UploadConfirmationModule { }
