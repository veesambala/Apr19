import {
  AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit,
  ViewChild, Output, EventEmitter
} from '@angular/core';
import { Event, NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { UgcCustomizationService } from '../../ugc-shared/services/ugc-customization/ugc-customization.service';
import { StepsProgressBarComponent } from './core/steps-progress-bar/steps-progress-bar.component';
import { StaticUtils } from '../../ugc-shared/services/static-utils';
import { UploadTrackerService } from './core/upload-tracker.service';

@Component({
  selector: 'ugc-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(StepsProgressBarComponent)
  public progressBar: StepsProgressBarComponent;
  @Output()
  public onPrimaryEventTriggered: EventEmitter<any> = new EventEmitter();

  public get pageTitle(): string {
    return this._pageTitle;
  }

  private _pageTitle: string;
  private _progressStepIndex: number;
  private _progressStepCompletionPercentage: number;
  private _nextRoute: string;
  private _routerSubscription: Subscription;

  constructor(
    private _customizationService: UgcCustomizationService,
    private _uploadTracker: UploadTrackerService,
    private _router: Router,
    private _changeDetector: ChangeDetectorRef
  ) {
    this._uploadTracker.clear();
  }

  public ngOnInit(): void {
    this._routerSubscription = this._router.events.subscribe(
      (event: Event): void => {
        if (event instanceof NavigationEnd) {
          this.pageChanged(event.url);
        }
      }
    );
    this.pageChanged(this._router.url);
  }

  public ngAfterViewInit(): void {
    this.updateProgressBar();
  }

  public ngOnDestroy(): void {
    if (this._routerSubscription) {
      this._routerSubscription.unsubscribe();
      this._routerSubscription = null;
    }
  }

  public primaryButtonClick(): void {
    this.onPrimaryEventTriggered.emit();
    this._router.navigate([this._nextRoute], { queryParams: StaticUtils.queryParams });
  }

  private pageChanged(url: string): void {
    if (url.indexOf('upload/add-media') > -1) {
      this._pageTitle = this._customizationService.locales.current().addMediaPageTitle;
      this._progressStepIndex = 0;
      this._progressStepCompletionPercentage = 100;
      this._nextRoute = 'ugc/upload/user-info';
    } else if (url.indexOf('upload/user-info') > -1) {
      this._pageTitle = this._customizationService.locales.current().addMediaPageTitle;
      this._progressStepIndex = 1;
      this._progressStepCompletionPercentage = 100;
      this._nextRoute = '/ugc/upload/upload-confirm';
    } else if (url.indexOf('upload/upload-confirm') > -1) {
      this._pageTitle = this._customizationService.locales.current().addMediaPageTitle;
      this._progressStepIndex = 2;
      this._progressStepCompletionPercentage = 100;
      this._nextRoute = '/ugc/upload/upload-inprogress';
    } else if (url.indexOf('upload/upload-inprogress') > -1) {
      this._pageTitle = this._customizationService.locales.current().formPageTitle;
      this._progressStepIndex = 2;
      this._progressStepCompletionPercentage = 100;
      this._nextRoute = '/ugc/upload/upload-success';
    } else if (url.indexOf('upload/terms-conditions') > -1) {
      this._pageTitle = this._customizationService.locales.current().termsAndConditionsPageTitle;
      this._progressStepIndex = 0;
      this._progressStepCompletionPercentage = 0;
    } else if (url.indexOf('upload/upload-success') > -1) {
      this._pageTitle = '';
      this._progressStepIndex = 0;
      this._progressStepCompletionPercentage = 0;
    }

    this.updateProgressBar();
    this._changeDetector.detectChanges();
  }

  private updateProgressBar(): void {
    if (!this.progressBar) {
      return;
    }

    this.progressBar.updateStepCompletionPercentage(this._progressStepIndex, this._progressStepCompletionPercentage);
  }
}
