import { NgModule } from '@angular/core';
import { SharedComponentsModule } from '../../ugc-shared/components/shared-components.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { routes } from './upload.routes';
import { UploadComponent } from './upload.component';
import { AddMediaModule } from './add-media/add-media.module';
import { UploadCoreModule } from './core/core.module';
import { UserInfoModule } from './user-info/user-info.module';
import { ProgressModule } from './progress/progress.module';
import { TermsAndConditionModule } from './terms-conditions/terms-conditions.module';
import { UploadConfirmationModule } from './upload-confirm/upload-confirmation.module';
import { SuccessModule } from './success/success.module';

@NgModule({
  declarations: [
    UploadComponent
  ],
  imports: [
    UploadCoreModule,
    SharedComponentsModule,
    AddMediaModule,
    UserInfoModule,
    ProgressModule,
    TermsAndConditionModule,
    UploadConfirmationModule,
    SuccessModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: []
})
export class UploadModule { }
