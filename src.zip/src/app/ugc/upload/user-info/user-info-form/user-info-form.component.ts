import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UgcCustomizationService } from
  '../../../../ugc-shared/services/ugc-customization/ugc-customization.service';
export interface UserInfo {
  name: string;
  email: string;
  title: string;
  firstName: string;
  lastName: string;
}

@Component({
  selector: 'user-info-form',
  templateUrl: './user-info-form.component.html',
  styleUrls: ['./user-info-form.component.scss', './user-info-form.component.theme.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserInfoFormComponent {
  public userInfoPrompt: string;
  public isEmailEntered: boolean;
  public userFormFields: {};
  public ugcUserInfo: UserInfo = {
    name: '',
    email: '',
    title: '',
    firstName: '',
    lastName: ''
  };

  constructor(
    private _customizationService: UgcCustomizationService
  ) {
    this.setText();
  }
  public labelOnMouseLeave() {
    this.isEmailEntered = this.ugcUserInfo['email'] === '' ? false : true;
  }
  public setText() {
    this.userFormFields = this._customizationService.locales.current().formField;
    this.userInfoPrompt = this._customizationService.locales.current().formPageHeadlineText;
  }
}
