import { Component } from '@angular/core';
import { StepsNavButtonsService } from '../core/steps-nav-buttons/steps-nav-buttons.service';
import { UgcCustomizationService } from '../../../ugc-shared/services/ugc-customization/ugc-customization.service';
import { UgcErrorReportService } from '../../../ugc-shared/services/ugc-error-report/ugc-error-report.service';

@Component({
  selector: 'user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.scss', './user-info.component.theme.scss']
})
export class UserInfoComponent {

  constructor(
    private _buttonsService: StepsNavButtonsService,
    private _customizationService: UgcCustomizationService,
    private _ugcErrorReportService: UgcErrorReportService
  ) {
    this._buttonsService.primaryButtonState = 'ENABLED';
    this._buttonsService.primaryButtonText = this._customizationService.locales.current().nextText;
  }
}
