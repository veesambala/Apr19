import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedComponentsModule } from '../../../ugc-shared/components/shared-components.module';
import { UserInfoComponent } from './user-info.component';
import { UserInfoPromptComponent } from './user-info-prompt/user-info-prompt.component';
import { UserInfoFormComponent } from './user-info-form/user-info-form.component';

@NgModule({
  declarations: [
    UserInfoComponent,
    UserInfoPromptComponent,
    UserInfoFormComponent
  ],
  imports: [SharedComponentsModule, CommonModule, FormsModule],
  exports: []
})
export class UserInfoModule { }
